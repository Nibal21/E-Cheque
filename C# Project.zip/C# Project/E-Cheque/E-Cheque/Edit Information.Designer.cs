﻿
namespace E_Cheque
{
    partial class Edit_Information
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.fetchbtn = new System.Windows.Forms.Button();
            this.userIdfetchtxtbox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.updatebutton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.updtusrnmtxtbox = new System.Windows.Forms.TextBox();
            this.EditUsernamelbl = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.addstreettxtbox = new System.Windows.Forms.TextBox();
            this.Edtaddbtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.addaddrstxtbox = new System.Windows.Forms.TextBox();
            this.addphntxtbox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.headlabel = new System.Windows.Forms.Label();
            this.Logolabel = new System.Windows.Forms.Label();
            this.edtgobackbtn = new System.Windows.Forms.Button();
            this.updateddataGridView = new System.Windows.Forms.DataGridView();
            this.additionaldataGridView = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.updateddataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.additionaldataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.PeachPuff;
            this.panel1.Controls.Add(this.fetchbtn);
            this.panel1.Controls.Add(this.userIdfetchtxtbox);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.updatebutton);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.updtusrnmtxtbox);
            this.panel1.Controls.Add(this.EditUsernamelbl);
            this.panel1.Location = new System.Drawing.Point(34, 154);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(323, 370);
            this.panel1.TabIndex = 2;
            // 
            // fetchbtn
            // 
            this.fetchbtn.BackColor = System.Drawing.Color.White;
            this.fetchbtn.FlatAppearance.BorderSize = 0;
            this.fetchbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fetchbtn.Location = new System.Drawing.Point(187, 91);
            this.fetchbtn.Name = "fetchbtn";
            this.fetchbtn.Size = new System.Drawing.Size(108, 35);
            this.fetchbtn.TabIndex = 33;
            this.fetchbtn.Text = "Fetch";
            this.fetchbtn.UseVisualStyleBackColor = false;
            this.fetchbtn.Click += new System.EventHandler(this.fetchbtn_Click);
            // 
            // userIdfetchtxtbox
            // 
            this.userIdfetchtxtbox.Location = new System.Drawing.Point(20, 91);
            this.userIdfetchtxtbox.Multiline = true;
            this.userIdfetchtxtbox.Name = "userIdfetchtxtbox";
            this.userIdfetchtxtbox.Size = new System.Drawing.Size(161, 35);
            this.userIdfetchtxtbox.TabIndex = 32;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(17, 71);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(57, 17);
            this.label8.TabIndex = 31;
            this.label8.Text = "User Id:";
            // 
            // updatebutton
            // 
            this.updatebutton.BackColor = System.Drawing.Color.White;
            this.updatebutton.FlatAppearance.BorderSize = 0;
            this.updatebutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.updatebutton.Location = new System.Drawing.Point(20, 236);
            this.updatebutton.Name = "updatebutton";
            this.updatebutton.Size = new System.Drawing.Size(275, 35);
            this.updatebutton.TabIndex = 30;
            this.updatebutton.Text = "Update";
            this.updatebutton.UseVisualStyleBackColor = false;
            this.updatebutton.Click += new System.EventHandler(this.updatebutton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(73, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(176, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "Update Information";
            // 
            // updtusrnmtxtbox
            // 
            this.updtusrnmtxtbox.Location = new System.Drawing.Point(20, 162);
            this.updtusrnmtxtbox.Multiline = true;
            this.updtusrnmtxtbox.Name = "updtusrnmtxtbox";
            this.updtusrnmtxtbox.Size = new System.Drawing.Size(275, 35);
            this.updtusrnmtxtbox.TabIndex = 4;
            // 
            // EditUsernamelbl
            // 
            this.EditUsernamelbl.AutoSize = true;
            this.EditUsernamelbl.Location = new System.Drawing.Point(17, 142);
            this.EditUsernamelbl.Name = "EditUsernamelbl";
            this.EditUsernamelbl.Size = new System.Drawing.Size(77, 17);
            this.EditUsernamelbl.TabIndex = 0;
            this.EditUsernamelbl.Text = "Username:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.PeachPuff;
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.addstreettxtbox);
            this.panel2.Controls.Add(this.Edtaddbtn);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.addaddrstxtbox);
            this.panel2.Controls.Add(this.addphntxtbox);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Location = new System.Drawing.Point(398, 154);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(323, 370);
            this.panel2.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(26, 222);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 17);
            this.label3.TabIndex = 33;
            this.label3.Text = "Street No.:";
            // 
            // addstreettxtbox
            // 
            this.addstreettxtbox.Location = new System.Drawing.Point(29, 242);
            this.addstreettxtbox.Multiline = true;
            this.addstreettxtbox.Name = "addstreettxtbox";
            this.addstreettxtbox.Size = new System.Drawing.Size(275, 35);
            this.addstreettxtbox.TabIndex = 32;
            // 
            // Edtaddbtn
            // 
            this.Edtaddbtn.BackColor = System.Drawing.Color.White;
            this.Edtaddbtn.FlatAppearance.BorderSize = 0;
            this.Edtaddbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Edtaddbtn.Location = new System.Drawing.Point(29, 297);
            this.Edtaddbtn.Name = "Edtaddbtn";
            this.Edtaddbtn.Size = new System.Drawing.Size(275, 35);
            this.Edtaddbtn.TabIndex = 31;
            this.Edtaddbtn.Text = "Add";
            this.Edtaddbtn.UseVisualStyleBackColor = false;
            this.Edtaddbtn.Click += new System.EventHandler(this.Edtaddbtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.Location = new System.Drawing.Point(87, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 25);
            this.label2.TabIndex = 7;
            this.label2.Text = "Add Information";
            // 
            // addaddrstxtbox
            // 
            this.addaddrstxtbox.Location = new System.Drawing.Point(29, 162);
            this.addaddrstxtbox.Multiline = true;
            this.addaddrstxtbox.Name = "addaddrstxtbox";
            this.addaddrstxtbox.Size = new System.Drawing.Size(275, 35);
            this.addaddrstxtbox.TabIndex = 8;
            // 
            // addphntxtbox
            // 
            this.addphntxtbox.Location = new System.Drawing.Point(29, 91);
            this.addphntxtbox.Multiline = true;
            this.addphntxtbox.Name = "addphntxtbox";
            this.addphntxtbox.Size = new System.Drawing.Size(275, 35);
            this.addphntxtbox.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(26, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Phone Number:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(26, 142);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Address:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkOrange;
            this.panel3.Controls.Add(this.headlabel);
            this.panel3.Controls.Add(this.Logolabel);
            this.panel3.Location = new System.Drawing.Point(-2, -2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1208, 123);
            this.panel3.TabIndex = 4;
            // 
            // headlabel
            // 
            this.headlabel.AutoSize = true;
            this.headlabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.headlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.headlabel.Location = new System.Drawing.Point(14, 56);
            this.headlabel.Name = "headlabel";
            this.headlabel.Size = new System.Drawing.Size(196, 29);
            this.headlabel.TabIndex = 3;
            this.headlabel.Text = "Edit Information";
            // 
            // Logolabel
            // 
            this.Logolabel.AutoSize = true;
            this.Logolabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Logolabel.Font = new System.Drawing.Font("Adobe Devanagari", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Logolabel.Location = new System.Drawing.Point(14, 11);
            this.Logolabel.Name = "Logolabel";
            this.Logolabel.Size = new System.Drawing.Size(87, 27);
            this.Logolabel.TabIndex = 2;
            this.Logolabel.Text = "E-Cheque";
            // 
            // edtgobackbtn
            // 
            this.edtgobackbtn.BackColor = System.Drawing.Color.White;
            this.edtgobackbtn.FlatAppearance.BorderSize = 0;
            this.edtgobackbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.edtgobackbtn.Location = new System.Drawing.Point(34, 547);
            this.edtgobackbtn.Name = "edtgobackbtn";
            this.edtgobackbtn.Size = new System.Drawing.Size(161, 35);
            this.edtgobackbtn.TabIndex = 34;
            this.edtgobackbtn.Text = "Go Back";
            this.edtgobackbtn.UseVisualStyleBackColor = false;
            this.edtgobackbtn.Click += new System.EventHandler(this.edtgobackbtn_Click);
            // 
            // updateddataGridView
            // 
            this.updateddataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.updateddataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.updateddataGridView.Location = new System.Drawing.Point(760, 174);
            this.updateddataGridView.Name = "updateddataGridView";
            this.updateddataGridView.RowHeadersWidth = 51;
            this.updateddataGridView.RowTemplate.Height = 24;
            this.updateddataGridView.Size = new System.Drawing.Size(423, 150);
            this.updateddataGridView.TabIndex = 35;
            // 
            // additionaldataGridView
            // 
            this.additionaldataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.additionaldataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.additionaldataGridView.Location = new System.Drawing.Point(760, 376);
            this.additionaldataGridView.Name = "additionaldataGridView";
            this.additionaldataGridView.RowHeadersWidth = 51;
            this.additionaldataGridView.RowTemplate.Height = 24;
            this.additionaldataGridView.Size = new System.Drawing.Size(423, 150);
            this.additionaldataGridView.TabIndex = 36;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(757, 154);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 17);
            this.label6.TabIndex = 37;
            this.label6.Text = "Updated Data:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(757, 356);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(108, 17);
            this.label7.TabIndex = 38;
            this.label7.Text = "Additional Data:";
            // 
            // Edit_Information
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1205, 608);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.additionaldataGridView);
            this.Controls.Add(this.updateddataGridView);
            this.Controls.Add(this.edtgobackbtn);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Edit_Information";
            this.Text = "Edit_Information";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.updateddataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.additionaldataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label EditUsernamelbl;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox addaddrstxtbox;
        private System.Windows.Forms.TextBox addphntxtbox;
        private System.Windows.Forms.Button updatebutton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox addstreettxtbox;
        private System.Windows.Forms.Button Edtaddbtn;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label Logolabel;
        private System.Windows.Forms.Label headlabel;
        private System.Windows.Forms.Button edtgobackbtn;
        private System.Windows.Forms.DataGridView updateddataGridView;
        private System.Windows.Forms.DataGridView additionaldataGridView;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button fetchbtn;
        private System.Windows.Forms.TextBox userIdfetchtxtbox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox updtusrnmtxtbox;
    }
}