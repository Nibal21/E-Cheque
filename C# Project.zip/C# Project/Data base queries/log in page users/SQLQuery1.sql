﻿Create table Logged_in_users
(Username varchar(50) not null,
Password nvarchar(50) not null,
Primary key(Username),
);



Select * from Logged_in_users